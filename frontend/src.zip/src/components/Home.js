import React from 'react';

const Home = () => {
  return (
    <div>
      <h1>Welcome to the Project Management App!</h1>
      <p>Please log in or register to get started.</p>
    </div>
  );
};

export default Home;